/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.tareagrupo;

/**
 *
 * 
 */
public class Laboratorio extends Hospital{
     private String examenes;
    public Laboratorio(String color, String dimensiones, String pisos, String examenes){
    super(color, dimensiones, pisos);
    this.examenes = examenes;
    
        
    }
    public void mostrarDatos(){
        
        System.out.println("El color del edificio es: " + obColor()+
                "/ La dimension del edificio es: " + obDim()+
                "/ Los pisos del edificio son: " + obPisos()+
                "/ En el laboratorio se hacen:"+ examenes);        
     }   
   @Override
    String obtenerInfo() {
        return "La informacion del laboratorio es:";
    }
    
}
