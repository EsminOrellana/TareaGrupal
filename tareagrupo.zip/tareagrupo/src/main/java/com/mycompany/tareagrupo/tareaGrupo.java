/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.tareagrupo;

/**
 *
 * 
 */
public class tareaGrupo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Farmacia farmacia = new Farmacia("rojo","150m cuadrados","4","Todo tipo de medicamentos");
        Laboratorio lab = new Laboratorio("blanco","200m cuadrados","3","examenes de todo tipo");
        
        
        System.out.println(farmacia.obtenerInfo());
        farmacia.mostrarDatos();
        System.out.println(lab.obtenerInfo());
        lab.mostrarDatos();
    }
    
}
